<?php

namespace SoftUniBlogRestApiBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SoftUniBlogRestApiBundle extends Bundle
{
}
