<?php

namespace SoftUniBologBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SoftUniBologBundle extends Bundle
{
}
